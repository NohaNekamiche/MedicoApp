package com.example.medico.DataClass


class Auth (
    val phone:String,
    val pwd:String
)