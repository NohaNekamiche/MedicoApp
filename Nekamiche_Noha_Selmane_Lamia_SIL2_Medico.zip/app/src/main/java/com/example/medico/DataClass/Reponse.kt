package com.example.medico.DataClass

class Reponse (
    val rep:String,
    val IdUser:Int,
    val obj:String
)