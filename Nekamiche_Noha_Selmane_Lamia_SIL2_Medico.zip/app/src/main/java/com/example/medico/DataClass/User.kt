package com.example.medico.DataClass

data class User(
        val nom:String,
        val prenom:String,
        val adr:String,
        val numTel:String,
        val email:String,
        val pwd:String,
        val role:String
)