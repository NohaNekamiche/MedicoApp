package com.example.medico.DataClass

data class Treatment (
            val idTraitement:Int,
            val idbooking:Int,
            val maladie:String,
            val explication:String,
            val medicaments:String,
            val dateFinTraitement:String
)