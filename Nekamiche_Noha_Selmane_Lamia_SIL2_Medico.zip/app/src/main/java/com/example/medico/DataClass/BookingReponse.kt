package com.example.medico.DataClass

data class BookingReponse (
        val msg:String,
        val booking: Rdv
        )