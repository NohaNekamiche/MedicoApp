package com.example.medico.ui.ListeConseil

import androidx.lifecycle.ViewModel

class ListeConseilViewModel:ViewModel() {
}