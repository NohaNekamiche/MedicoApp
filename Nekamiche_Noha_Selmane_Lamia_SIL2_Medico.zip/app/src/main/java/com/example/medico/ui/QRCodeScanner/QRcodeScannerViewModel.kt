package com.example.medico.ui.QRCodeScanner

import androidx.lifecycle.ViewModel

class QRcodeScannerViewModel :ViewModel() {
}