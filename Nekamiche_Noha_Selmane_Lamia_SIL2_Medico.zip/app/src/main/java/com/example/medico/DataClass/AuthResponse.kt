package com.example.medico.DataClass

class AuthResponse (
        val msg:String,
        val token:String,
        val idUser:Int
)