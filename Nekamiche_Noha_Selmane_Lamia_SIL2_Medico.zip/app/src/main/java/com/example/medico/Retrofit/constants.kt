package com.example.medico.Retrofit


val baseUrl="https://2ebee7e77d02.ngrok.io/"

val BASE_URL="https://2ebee7e77d02.ngrok.io/"
