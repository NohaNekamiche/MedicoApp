package com.example.medico.DataClass

data class Heure (
        val heure: String
        )