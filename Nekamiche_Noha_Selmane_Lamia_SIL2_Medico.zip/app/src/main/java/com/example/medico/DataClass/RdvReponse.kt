package com.example.medico.DataClass

class RdvReponse(
    val idbooking:String,
    val IdDoc:Int,
    val IdPatient:Int,
    val date:String,
    val heure:String,
    val Titre:String,
    val idUser:Int,
    val specialite:String,
    val photo:String,
    val latCabinet:String,
    val langCabinet:String,
    val name:String,
    val username:String,
    val adr:String,
    val phone:String,
    val pwd:String,
    val Role:String


)