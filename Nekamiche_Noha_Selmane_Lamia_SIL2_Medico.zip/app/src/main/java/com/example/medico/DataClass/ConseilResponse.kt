package com.example.medico.DataClass

class ConseilResponse(
        val idconseil:Int,
        val obj:String,
        val IdDoc:Int,
        val idUser:Int,
        val IdPatient:Int,
        val msg:String,val reponse:String,
        val specialite:String,
        val photo:String,
        val latCabinet:String,
        val langCabinet:String,
        val name:String,
        val username:String,
        val adr:String,
        val phone:String,
        val pwd:String,
        val Role:String
)