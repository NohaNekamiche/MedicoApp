package com.example.medico.DataClass


class TraitementResponse (
        val idTraitement:Int,
        val idBooking:Int,
        val name:String,
        val username:String,
        val phone:String,
        val adr:String,
        val maladie:String,
        val explication:String,
        val medicaments:String,
        val dateFinTraitement:String,
        val idDoc:Int,
        val idPatient:Int,
        val date:String,
        val heure:String,
        val Titre:String,
        val latCabinet:String,
        val langCabinet:String,
        val photo:String

)