package com.example.medico.ui.ConseilDetail

import androidx.lifecycle.ViewModel

class ConseilDetailViewModel :ViewModel() {
}