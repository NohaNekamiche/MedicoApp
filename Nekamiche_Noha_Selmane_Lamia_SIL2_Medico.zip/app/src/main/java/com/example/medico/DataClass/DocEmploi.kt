package com.example.medico.DataClass

data class DocEmploi (
    val id:Int,
    val IdDoc:Int,
    val dateLibre:String,
    val heure:String
)