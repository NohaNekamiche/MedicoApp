package com.example.medico.DataClass


data class Conseil (
    val idconseil:Int,
    val obj:String,
    val IdDoc:Int,
    val IdPatient:Int,
    val msg:String,val reponse:String
    )